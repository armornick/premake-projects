--
-- msc.lua
-- Interface for the MS C/C++ compiler.
-- Copyright (c) 2009 Jason Perkins and the Premake project
--

	
	premake.msc = { }
	premake.msc.namestyle = "windows"
