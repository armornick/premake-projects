#include "stdafx.h"

int main()
{
	printf("CppConsoleApp\n");
	return 0;
}
